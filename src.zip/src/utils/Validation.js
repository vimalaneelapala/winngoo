export default validation={
    emailRegex:"/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/"
}